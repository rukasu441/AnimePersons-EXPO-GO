import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function Dragonball() {
  const anime = 
`A saga completa de Dragon Ball acompanha a vida inteira de Son Goku, desde que ele era um garoto ingênuo com cauda de macaco vivendo isolado nas montanhas, até se tornar o guerreiro mais poderoso do universo. A história começa quando ele conhece Bulma, uma jovem cientista obstinada a encontrar as sete mágicas Esferas do Dragão que, quando reunidas, invocam o dragão Shenlong para realizar qualquer desejo. Inicialmente focada em artes marciais tradicionais e torneios de luta cheios de humor, a narrativa sofre uma transformação radical quando Goku descobre sua verdadeira origem: ele pertence aos Saiyajins, uma raça alienígena de conquistadores violentos enviada para destruir planetas.
A partir dessa revelação, o anime eleva suas proporções a níveis cósmicos. Goku e seus aliados — os Guerreiros Z, que incluem antigos rivais redimidos como Vegeta e Piccolo — tornam-se a linha de frente de defesa da Terra e do universo contra ameaças de magnitude apocalíptica. Eles enfrentam o imperador tirano Freeza, o bio-androide perfeito Cell, a força mágica caótica de Majin Boo e, eventualmente, deuses da destruição e guerreiros de outras dimensões. A obra foca na superação constante de limites através do treino, imortalizando o conceito de transformações visuais (como o Super Saiyajin) e estabelecendo a base para o formato moderno de lutas colossais e coreografadas que definiram a cultura pop mundial.
`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Dragon Ball</Text>
        <Text style={estilo.subtitulo}>
        Akira Toriyama
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {anime}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});