import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function Bleach() {
  const anime = 
`Bleach adota uma abordagem urbana e espiritual contemporânea, focada na vida de Ichigo Kurosaki, um estudante de ensino médio de dezoito anos que vive na cidade de Karakura. Ichigo sempre foi diferente dos outros jovens devido ao seu cabelo ruivo natural e a uma habilidade incomum e perturbadora: ele consegue ver, conversar e tocar nas almas dos mortos. Sua rotina muda drasticamente quando ele cruza o caminho de Rukia Kuchiki, uma Shinigami (Ceifadora de Almas) cuja missão é purificar espíritos corrompidos conhecidos como Hollows e guiar as almas humanas pacíficas para a Sociedade das Almas (o pós-vida). Durante uma emboscada em que sua família é atacada por um Hollow massivo, Rukia é gravemente ferida e tenta transferir metade de seus poderes para Ichigo. Para o espanto dela, o garoto absorve a totalidade de sua energia espiritual, manifestando uma espada gigante e derrotando o monstro com facilidade.
A partir desse evento, Ichigo é forçado a assumir o papel de Shinigami substituto para proteger sua cidade. No entanto, transferir poderes a um humano é um crime capital nas leis do mundo espiritual, e Rukia é capturada e levada de volta à Sociedade das Almas para ser executada. Para salvá-la, Ichigo e seus amigos — que também despertam habilidades espirituais únicas — invadem a dimensão dos ceifeiros. O que começa como uma missão de resgate desesperada revela uma imensa e sofisticada conspiração interna orquestrada por Sōsuke Aizen, um dos capitães mais brilhantes e traiçoeiros das divisões Shinigami. A história se aprofunda em guerras secretas entre diferentes facções espirituais, o domínio de espadas místicas que possuem consciência própria (Zanpakuto) e a luta constante de Ichigo para controlar o lado sombrio e monstruoso que cresce dentro de sua própria alma.
`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Bleach</Text>
        <Text style={estilo.subtitulo}>
        Tite Kubo
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {anime}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});