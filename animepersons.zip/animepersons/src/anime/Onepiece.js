import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function Onepiece() {
  const anime = 
`One Piece constrói um dos mundos mais vastos, detalhados e politicamente complexos da ficção na história do Monkey D. Luffy, um garoto que ganhou o poder de esticar seu corpo como borracha após comer acidentalmente uma Akuma no Mi (Fruta do Diabo). Inspirado pelo pirata que salvou sua vida na infância, Luffy decide ir para o mar com um objetivo monumental: encontrar o lendário tesouro conhecido como "One Piece", escondido pelo falecido Rei dos Piratas, Gol D. Roger, e reivindicar para si o título de novo Rei dos Piratas. Para Luffy, ser o Rei dos Piratas não significa dominar terras ou riquezas, mas sim possuir o maior nível de liberdade que um homem pode ter em todo o oceano.
O anime é estruturado através de grandes arcos narrativos em que Luffy navega por mares perigosos e imprevisíveis como a Grand Line e o Novo Mundo, recrutando um grupo eclético de desajustados para a sua tripulação, os Piratas do Chapéu de Palha — incluindo o espadachim Zoro, a navegadora Nami, o cozinheiro Sanji e o médico Chopper, cada um com seus próprios sonhos impossíveis. Embora a estética inicial pareça colorida e fantasiosa, a obra aborda temas sociais extremamente densos em cada ilha que a tripulação visita. Sob a superfície da aventura, o enredo expõe as engrenagens podres do mundo: a tirania implacável do Governo Mundial, o racismo estrutural contra homens-peixe, a escravidão comandada por nobres mundiais conhecidos como Dragões Celestiais, a censura histórica de um século apagado e os jogos de poder brutais dos Yonkou (os quatro imperadores piratas que comandam os mares).

`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>One Piece</Text>
        <Text style={estilo.subtitulo}>
        Eiichiro Oda
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {anime}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});