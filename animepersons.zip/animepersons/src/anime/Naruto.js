import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function Naruto() {
  const anime = 
`Naruto mergulha em um universo governado por clãs ninjas rivais e vilas militares ocultas, centrando-se na vida de Naruto Uzumaki. O jovem órfão cresceu sob o peso do desprezo e do isolamento social crônico. Isso ocorreu porque, quando ele ainda era um bebê, o líder de sua comunidade sacrificou a própria vida para selar a Raposa de Nove Caudas, um demônio de puro chakra destrutivo, dentro do corpo do menino. Para os moradores da Vila da Folha, Naruto não era uma criança comum, mas a própria personificação da fera que quase os destruiu. Para combater a solidão e provar seu valor a todos que o rejeitaram, Naruto estabelece uma meta de vida inabalável: tornar-se o Hokage, o ninja mais forte e respeitado da vila.
A narrativa acompanha sua graduação na academia ninja, onde ele é colocado no Time 7 ao lado de Sakura Haruno e seu maior rival e amigo, Sasuke Uchiha, sob a tutela do mentor Kakashi Hatake. A trama se expande drasticamente quando Sasuke, consumido pelo desejo de vingança contra seu irmão mais velho por ter exterminado todo o seu clã, abandona a vila em busca de poder proibido com o vilão Orochimaru. A busca obsessiva de Naruto para resgatar seu amigo e trazê-lo de volta à luz torna-se o motor emocional da história. À medida que os personagens crescem, o enredo evolui para uma complexa rede de conspirações geopolíticas, dilemas morais sobre o ciclo infinito de ódio e guerra, e a ameaça global da Akatsuki, uma organização de ninjas renegados de elite que busca capturar todas as feras com cauda para reescrever a ordem do mundo.

`;

  return (
    <ScrollView>
      <View style={estilo.container}>
        <Text style={estilo.titulo}>Naruto</Text>
        <Text style={estilo.subtitulo}>
        Masashi Kishimoto
        </Text>

        <View style={estilo.resumo}>
          <Text style={estilo.textoResumo}>
            {anime}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
    paddingBottom: 30,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: '700',
    marginTop: 50,
    marginBottom: 10,
  },
  subtitulo: {
    fontSize: 20,
    textAlign: 'center',
    color: '#E6E6FA',
    marginBottom: 20,
  },
  resumo: {
    marginHorizontal: 25,
    backgroundColor: '#ffffff70',
    borderRadius: 7,
    padding: 12,
  },
  textoResumo: {
    fontSize: 16,
    lineHeight: 27,
    color: '#FFFFE0',
  },
});