import * as react from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Dragonball from './anime/Dragonball';
import Naruto from './anime/Naruto';
import Bleach from './anime/Bleach';
import Onepiece from './anime/Onepiece';
import Anime from './pages/Anime';

const Stack = createStackNavigator();

export default function RotasButtomAnime() {
  return (
    <Stack.Navigator>
    <Stack.Screen name="Anime" component={Anime} options = {{headerShown:false}} />
    <Stack.Screen name="Dragonball" component={Dragonball} options = {{title:"Dragon Ball"}} />
    <Stack.Screen name="Naruto" component={Naruto} options = {{title:"Naruto"}} />
    <Stack.Screen name="Bleach" component={Bleach} options = {{title:"Bleach"}} />
    <Stack.Screen name="Onepiece" component={Onepiece} options = {{title:"One Piece"}} />
    </Stack.Navigator>
  );
}

