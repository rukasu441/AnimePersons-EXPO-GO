import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Ichigo() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Ichigo</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/ichigo3.jpg')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/ichigo3.jpg')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/ichigo2.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Ichigo Kurosaki contrasta com seus colegas por adotar uma postura mais pragmática, cética e séria, funcionando como o estudante que repentinamente herda os poderes de um Ceifador de Almas. Dono de uma linhagem espiritual mista singular que une heranças de Shinigamis, Quincys e Hollows, ele empunha a Zangetsu e desfere o devastador Getsuga Tensho unicamente para defender sua família e os inocentes ao seu redor. Ichigo representa um protetor realista e direto, que dispensa discursos grandiosos sobre mudar o mundo para focar no que realmente importa: manter quem ama a salvo de qualquer ameaça sobrenatural.
 </Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});