import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Naruto() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Naruto</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/naruto2.jpg')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/naruto1.jpg')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/naruto3.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Naruto Uzumaki carrega uma trajetória de superação emocional profunda, tendo crescido como um órfão rejeitado na Vila da Folha por abrigar em seu interior a temida Raposa de Nove Caudas. Barulhento, teimoso e movido pelo lema de nunca voltar atrás em sua palavra, ele transformou a dor da solidão e do preconceito no sonho de se tornar o líder de seu povo, o Hokage. Utilizando seus clones das sombras, o Rasengan e o poder do Modo Sábio, Naruto ensinou ao público o valor inestimável da empatia, do perdão e da perseverança diante das maiores adversidades do destino.
</Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
  },
  img: {
    width: 360,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});