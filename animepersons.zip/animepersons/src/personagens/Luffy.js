import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Luffy() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Luffy</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/luffy1.jpg')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/luffy2.jpeg')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/luffy3.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Monkey D. Luffy personifica a busca pela liberdade absoluta como um jovem pirata de chapéu de palha cujo corpo ganhou propriedades elásticas após comer uma Fruta do Diabo acidentalmente na infância. Extrovertido, sonhador e ferozmente protetor com seus companheiros de tripulação, ele navega pelos mares em busca do tesouro definitivo rumo ao título de Rei dos Piratas. Ao dominar as marchas de combate e despertar o lendário poder do Deus do Sol Nika, Luffy prova que a verdadeira força de um capitão reside na capacidade de unir pessoas e quebrar correntes opressoras.
</Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});