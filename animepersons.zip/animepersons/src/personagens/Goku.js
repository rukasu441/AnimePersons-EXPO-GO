import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView} from 'react-native';

export default function Goku() {
  return (
    <ScrollView>
    <View style={estilo.container}>
    <Text style={estilo.titulo}> Goku</Text>
    <View>
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/goku2.jpg')}
     />
     </View>
     

    <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/goku3.jpg')}
     />
     </View>

         <View>
    <Image
     resizeMode={'stretch'}
     style={estilo.img}
     source={require('../../assets/goku1.jpg')}
     />
     </View>
     </ScrollView>
     </View>
     <View style={estilo.resumo}>
     <Text style={estilo.textoResumo}>
Son Goku, nascido Kakaroto no Planeta Vegeta e criado na Terra pelo avô Gohan, é o lendário guerreiro Saiyajin que definiu o arquétipo do herói focado na superação pessoal. Alegre, ingênuo e com um apetite voraz por desafios, ele não luta por ódio ou vingança, mas sim para testar seus próprios limites e enfrentar oponentes formidáveis. Munido de transformações icônicas como o Super Saiyajin e o divino Instinto Superior, além do clássico Kamehameha, Goku abriu caminho para toda uma geração de histórias de ação e continua sendo a maior referência de inspiração para outros autores.
 </Text>
      </View>
      </View>
      </ScrollView>
  );
}
const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#9370DB',
  },
  img: {
    width: 330,
    height: 400,
    marginHorizontal: 25,
    borderRadius: 10,
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#FFC0CB',
    fontWeight: 700,
    marginTop: 50,
    marginBottom: 30,
  },
  resumo: {
    marginTop: 20,
    marginHorizontal: 15,
    backgroundColor: '#ffffff70',
    color: '#FFFFE0',
    borderRadius: 7,
    padding: 8,
  },
  textoResumo: {
    fontSize: 19,
  },
});