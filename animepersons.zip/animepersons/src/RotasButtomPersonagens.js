import * as react from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Goku from './personagens/Goku';
import Naruto from './personagens/Naruto';
import Ichigo from './personagens/Ichigo';
import Luffy from './personagens/Luffy';
import Personagens from './pages/Personagens';

const Stack = createStackNavigator();

export default function RotasButtomPersonagens() {
  return (
    <Stack.Navigator>
    <Stack.Screen name="Personagens" component={Personagens} options = {{headerShown:false}} />
    <Stack.Screen name="Goku" component={Goku} options = {{title:"Goku"}} />
    <Stack.Screen name="Naruto" component={Naruto} options = {{title:"Naruto"}} />
    <Stack.Screen name="Ichigo" component={Ichigo} options = {{title:"Ichigo"}} />
    <Stack.Screen name="Luffy" component={Luffy} options = {{title:"Luffy"}} />
    </Stack.Navigator>
  );
}
