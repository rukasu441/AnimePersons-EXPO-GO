import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function Personagens(props) {
  return (
    <View style={estilo.container}>
      <Text style={estilo.titulo}> Os melhores Personagens</Text>

      <FlatList
        data={personagens}
        renderItem={({ item }) => (
          <View style={estilo.artista}>
            <TouchableOpacity
              onPress={() => {
                props.navigation.navigate(item.buttom);
              }}>
              <Text style={estilo.txtArtista}> {item.nome}</Text>
            </TouchableOpacity>
            <View style={estilo.rede}>
              <Text style={estilo.curtidas}>
                <MaterialCommunityIcons
                  name="thumb-up"
                  size={20}
                  color={'#F00'}
                />
                {item.like} Curtidas
              </Text>
              <Text style={estilo.seguidores}>
                <MaterialCommunityIcons
                  name="account-heart"
                  size={20}
                  color={'blue'}
                />
                {item.seguidores} Seguidores
              </Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const personagens = [
  {
    uid: 1,
    nome: 'Goku',
    like: '693M',
    seguidores: "23M",
    buttom: 'Goku',
  },
  {
    uid: 2,
    nome: 'Naruto',
    like: '381M',
    seguidores: '17,5M',
    buttom: 'Naruto',
  },
  {
    uid: 3,
    nome: 'Ichigo',
    like: '309M',
    seguidores: '43M',
    buttom: 'Ichigo',
  },
  {
    uid: 4,
    nome: 'Luffy',
    like: '604M',
    seguidores: '32M',
    buttom: 'Luffy',
  },
];

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#8A2BE2',
  },
  artista: {
    backgroundColor: '#E6E6FA',
    justifyContent: 'center',
    margin: 15,
    padding: 5,
    borderRadius: 10,
    alignContent: 'center',
    textAlign: 'center',
  },
  titulo: {
    fontSize: 30,
    textAlign: 'center',
    color: '#ffffff',
    fontWeight: 700,
    marginVertical: 30,
  },
  rede: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  txtArtista: {
    fontSize: 20,
  },
});
